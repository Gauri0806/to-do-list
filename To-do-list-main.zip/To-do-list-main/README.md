# To-do-list
A simple to-do list built with the help of HMTL, CSS and Javascript
